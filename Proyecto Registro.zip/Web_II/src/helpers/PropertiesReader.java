package helpers;


import java.io.InputStream;
import java.util.Properties;

public class PropertiesReader {
	
	Properties p = new Properties();
	
	
	public PropertiesReader() {
		try(InputStream is = getClass().getClassLoader().getResourceAsStream("configurationSQL.properties")){
			p.load(is);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public String getSentence(String sql) {
		return p.getProperty(sql);
	}
	
	
}
