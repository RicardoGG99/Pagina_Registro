package helpers;


import java.sql.Connection;




import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	//Attributes
	private static String DBurl = "jdbc:postgresql://localhost:5432/postgres";
	private static String DBuser = "postgres";
	private static String DBpassword = "masterkey";
	private static String DBdriver = "org.postgresql.Driver";
	private Connection conn = null;
	
	//Methods
	public Connection getConnection() {
		
		if(conn == null) {
		try {
			Class.forName(DBdriver);
			conn = DriverManager.getConnection(DBurl, DBuser, DBpassword);
			System.out.println("Conexion Exitosa");
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("No se pudo conectar a la Base de Datos");
		}
		}
		return conn;
	}
	
}

